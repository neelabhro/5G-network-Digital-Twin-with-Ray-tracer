import numpy as np
import matplotlib.pyplot as plt

# Example signal strength data
signal_strength = np.random.rand(100, 100)  # Replace with your data

# Save heatmap as an image
plt.figure(figsize=(6, 6))
plt.imshow(signal_strength, cmap="viridis", origin="lower")
plt.colorbar(label="Signal Strength")
plt.axis("off")
plt.savefig("heatmap.png", bbox_inches="tight", pad_inches=0)
plt.close()
