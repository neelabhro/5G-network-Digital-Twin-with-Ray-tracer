import data_processing as dp 

result1, result2, result3 = dp.data_processing("data/rsrp_results.txt","data/measurements_rsrp.txt",1,False)

print(result1) #measurement array (Collected data)
print(result2) #raytracer data only
print(result3) #Full coordinates () use for data    