import numpy as np

def data_processing(raytracer_file, validation_file, samples, average=False, n=1):

    ## Function for data processing
    ## Process two txt files: One with Siona Raytracer signal strength and from measurement scripts using 5G dongle 
    ## The script is able to average datapoints if multiple are taken and also remove any outliers in antenna measurements

    measurements = []
    raytracer = []
    coordinates = []
    # Process measurement data 
    with open(validation_file, "r") as file:
        temp_measurements = []  # Temporary storage for a group of 5 lines
        measurements = []       # Final list to store averaged measurements
        average_n = n           # Number of lines to average into one entry
        diff_max = 50           # Maximum difference to not include outliers

        for line in file:
            parts = line.strip().split(":")[1].split(",")
            parts.pop()
            try:
                # Convert parts to integers, skip if conversion fails
                values = [int(part) for part in parts]
            except ValueError:
                # Skip this line if it contains non-integer data
                continue

            # Remove outliers based on diff_max
            measurement = [
                int(values[0]) if abs(values[i] - values[0]) > diff_max else values[i]
                for i in range(len(values))
            ]

            # Add the processed measurement to the temporary storage
            temp_measurements.append(measurement)

            # If we have `average_n` lines, compute the average and reset temp storage
            if len(temp_measurements) == average_n:
                # Average the rows (column-wise) and store the result
                averaged_measurement = [
                    sum(row[i] for row in temp_measurements) / average_n
                    for i in range(len(temp_measurements[0]))
                ]
                measurements.append(averaged_measurement)
                temp_measurements = []  # Reset for the next group

    # Process raytracer data: x, y, z, RSRP
    with open(raytracer_file, "r") as file:
        next(file)
        for line in file:
            parts = line.strip().split(",")
            # Convert parts to float and append
            #print(parts[-1])
            for i in range(samples):
                raytracer.append(float(parts[-1]))#[float(part) for part in parts])
                # Extract first two coordinates
                coordinates.append([float(parts[i]) for i in range(3)])


    # Convert lists to numpy arrays
    measurement_array = np.array(measurements)
    validation_array = np.array(raytracer)
    coordinate_array = np.array(coordinates)
    with_coords = np.hstack((coordinate_array, measurement_array))


    # Save the processed data
    # Save files directly to the 'data_clean' folder
    np.savetxt("data_clean/clean_measurement.txt", measurement_array, fmt="%d", delimiter=",")
    np.savetxt("data_clean/clean_raytracer.txt", validation_array, fmt="%f")
    np.savetxt("data_clean/clean_coordinates.txt", with_coords, fmt="%f", delimiter=",")

    return measurement_array, validation_array, coordinate_array

