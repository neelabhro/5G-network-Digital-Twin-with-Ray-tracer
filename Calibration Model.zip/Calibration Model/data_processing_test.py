import data_processing as dp 

result1, result2, result3 = dp.data_processing("data/rsrp_results.txt","data/measurements_rsrp.txt",False)

# print(result1)
print(result2)
# print(result3)