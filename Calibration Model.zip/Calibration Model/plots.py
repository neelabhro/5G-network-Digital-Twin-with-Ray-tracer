import matplotlib.pyplot as plt

def plots(train_losses, train_r2_scores):
    # Plot cost per epoch (loss) and accuracy per epoch (R2)
    plt.figure(figsize=(12, 6))
    
    # Plot Loss
    plt.subplot(1, 2, 1)
    plt.plot(train_losses, label='Loss')
    plt.title('Training Loss per Epoch')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.grid(True)
    
    # Plot R2 score
    plt.subplot(1, 2, 2)
    plt.plot(train_r2_scores, label='R2 Score', color='orange')
    plt.title('Training R2 per Epoch')
    plt.xlabel('Epoch')
    plt.ylabel('R2 Score')
    plt.grid(True)
    
    # Save the plots to file
    plt.tight_layout()
    plt.savefig('training_plots.png')  # Save as PNG file
    print("Plots saved as 'training_plots.png'")