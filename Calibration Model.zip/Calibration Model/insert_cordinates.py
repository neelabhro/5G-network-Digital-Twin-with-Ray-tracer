# File paths
coordinates_file = "data_clean/clean_coordinates.txt"
measurements_file = "data/measurements_rsrp.txt"
output_file = "data_clean/output.txt"

# Parameters
n = 3  # Number of measurements per coordinate set (update as needed)

# Read data from files
with open(coordinates_file, "r") as coord_file, open(measurements_file, "r") as meas_file:
    # Read all lines from coordinates and measurements
    coord_lines = [line.strip() for line in coord_file]
    meas_lines = [line.strip() for line in meas_file]

# Combine coordinates with measurements
combined_lines = []
coord_index = 0  # Track the current coordinate index

for i in range(0, len(coord_lines), n):  # Process measurements in chunks of n
    current_coord = coord_lines[coord_index]  # Get the current coordinate
    for j in range(i, i + n):  # Process n measurements for the current coordinate
        combined_line = current_coord + "," + meas_lines[j]
        combined_lines.append(combined_line)
    coord_index += 1  # Move to the next coordinate

# Write the combined data to the output file
with open(output_file, "w") as out_file:
    out_file.write("\n".join(combined_lines))

print(f"Combined data written to {output_file}")
