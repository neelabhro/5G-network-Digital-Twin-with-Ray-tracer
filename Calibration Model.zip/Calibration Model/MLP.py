import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import data_processing
import plots

class SignalCorrectionMLP(nn.Module):
    def __init__(self, input_dim, hidden_layers=[64, 32, 32, 32, 32, 32]):
        super(SignalCorrectionMLP, self).__init__()
        
        layers = []
        prev_dim = input_dim
        
        for layer_dim in hidden_layers:
            layers.extend([ 
                nn.Linear(prev_dim, layer_dim),
                nn.BatchNorm1d(layer_dim),
                nn.ReLU(),
                nn.Dropout(0.1)
            ])
            prev_dim = layer_dim
        
        layers.append(nn.Linear(prev_dim, 1))
        self.model = nn.Sequential(*layers)

                # Weight initialization
        self.apply(self._init_weights)
    
    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            nn.init.xavier_uniform_(module.weight)
            if module.bias is not None:
                nn.init.constant_(module.bias, 0)
    
    def forward(self, x):
        return self.model(x)

class SignalCorrectionPipeline:
    def __init__(self, input_dim):
        self.scaler = StandardScaler()
        self.model = SignalCorrectionMLP(input_dim=input_dim)
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(self.device)
    
    def prepare_data(self, X_raytracer, y_actual, test_size=0.2):
        X_train, X_test, y_train, y_test = train_test_split(X_raytracer, y_actual, test_size=test_size, random_state=42)
        X_train_scaled = self.scaler.fit_transform(X_train) # Standardize data 
        X_test_scaled = self.scaler.transform(X_test) # Uses statistics derived from X_train

        # Tensor transformation for ML model
        self.X_train_tensor = torch.FloatTensor(X_train_scaled).to(self.device)
        self.y_train_tensor = torch.FloatTensor(y_train).view(-1, 1).to(self.device)
        self.X_test_tensor = torch.FloatTensor(X_test_scaled).to(self.device)
        self.y_test_tensor = torch.FloatTensor(y_test).view(-1, 1).to(self.device)
        
        return self.X_train_tensor, self.y_train_tensor
    
    def train(self, epochs=500, learning_rate=0.01):
        criterion = nn.MSELoss()
        optimizer = optim.Adam(self.model.parameters(), lr=learning_rate, weight_decay=1e-5)

        # Track the loss and R-squared
        train_losses = []
        train_r2_scores = []
        
        for epoch in range(epochs):
            self.model.train()
            outputs = self.model(self.X_train_tensor)
            loss = criterion(outputs, self.y_train_tensor)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            # Calculate R-squared (coefficient of determination)
            with torch.no_grad():
                y_train_pred = self.model(self.X_train_tensor)
                ss_total = torch.sum((self.y_train_tensor - torch.mean(self.y_train_tensor))**2)
                ss_residual = torch.sum((self.y_train_tensor - y_train_pred)**2)
                r2 = 1 - (ss_residual / ss_total)
            
            train_losses.append(loss.item())
            train_r2_scores.append(r2.item())
            
            if epoch % 50 == 0:
                print(f'Epoch [{epoch+1}/{epochs}], Loss: {loss.item():.4f}, R2: {r2.item():.4f}')
        
        return self.model, train_losses, train_r2_scores
    
    def evaluate(self):
        self.model.eval()
        with torch.no_grad():
            test_predictions = self.model(self.X_test_tensor)
            mse = nn.MSELoss()(test_predictions, self.y_test_tensor)
            
            # Calculate R-squared for test set
            ss_total = torch.sum((self.y_test_tensor - torch.mean(self.y_test_tensor))**2)
            ss_residual = torch.sum((self.y_test_tensor - test_predictions)**2)
            r2 = 1 - (ss_residual / ss_total)
            
            print(f'Test Mean Squared Error: {mse.item():.4f}')
            print(f'Test R-squared: {r2.item():.4f}')
        
        return test_predictions.cpu().numpy()
    
    def predict(self, X_raytracer):
        X_scaled = self.scaler.transform(X_raytracer)
        X_tensor = torch.FloatTensor(X_scaled).to(self.device)
        
        self.model.eval()
        with torch.no_grad():
            predictions = self.model(X_tensor)
        
        return predictions.cpu().numpy()

def main():
    #dim 
    n = 4
    samples = 5
    data_dir = "data/"
    raytracer_file = "rsrp_results.txt" #clean_raytracer.txt"
    measurements_file = "measurements_rsrp.txt"

    X_raytracer, y_actual, coordinates = data_processing.data_processing(data_dir+raytracer_file,data_dir+measurements_file,5)

    # Create the pipeline and prepare data
    pipeline = SignalCorrectionPipeline(input_dim=n)
    X_train, y_train = pipeline.prepare_data(X_raytracer, y_actual, 0.1)

    # Train model and capture loss and R2 per epoch
    trained_model, train_losses, train_r2_scores = pipeline.train(1000, 0.01)
    
    # Evaluate performance
    predictions = pipeline.evaluate()

    # Plots 
    plots.plots(train_losses, train_r2_scores)
    
    # Predict on new ray tracer data
    corrected_predictions = pipeline.predict(X_raytracer[0:9])
    print("Corrected Predictions Shape:", corrected_predictions.shape)
    print("Original Input Values: \n", X_raytracer[0:9,0].reshape(-1, 1))
    print("Corrected Predictions: \n", corrected_predictions)
    print("Correct Values: \n",y_actual[0:9])
    print("Difference in prediction and output: \n", corrected_predictions-y_actual[0:9].reshape(-1, 1))

if __name__ == "__main__":
    main()
