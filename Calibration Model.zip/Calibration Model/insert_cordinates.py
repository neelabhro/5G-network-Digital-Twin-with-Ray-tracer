# File paths
# coordinates_file = "data_clean/clean_coordinates.txt"
# measurements_file = "data_clean/clean_measurement.txt"
# output_file = "data_clean/added_coordinates.txt"

# # Parameters
# n = 3  # Number of measurements per coordinate set (update as needed)

# Obsolete Code --> Ignore

def added_coord(coordinate_file,measurement_file,samples):
    # Read data from files
    with open(coordinate_file, "r") as coord_file, open(measurement_file, "r") as meas_file:
        # Read all lines from coordinates and measurements
        coord_lines = [line.strip() for line in coord_file]
        meas_lines = [line.strip() for line in meas_file]

    # Combine coordinates with measurements
    combined_lines = []
    coord_index = 0  # Track the current coordinate index
    current_meas = 0
    print(len(meas_lines))

    for i in range(0, len(coord_lines)):  # Process measurements in chunks the size of samples 
        current_coord = coord_lines[coord_index]  # Get the current coordinate
        
        for j in range(samples):  # Process n measurements for the current coordinate
            print(current_meas)
            combined_line = current_coord + "," + meas_lines[current_meas]
            combined_lines.append(combined_line)
            current_meas += 1
        coord_index += 1  # Move to the next coordinate

    # Write the combined data to the output file
    with open("data_clean/added_coords.txt", "w") as out_file:
        out_file.write("\n".join(combined_lines))

    print(f"Combined data written to added_coords.txt")


added_coord("data_clean/clean_coordinates.txt","data_clean/clean_measurement.txt", 5)