import data_processing 
data_processing.data_processing("measurements_rsrp.txt","measurements_sinr.txt")