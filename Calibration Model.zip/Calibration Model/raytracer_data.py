def main(filename="raytracer_data.txt"):
    data = []  # List to store all measurements
    stop = False  # Flag to terminate the script

    while not stop:
        # Prompt for a measurement
        print("Enter input with format: signal strength 1, ..., signal strength n, x, y")
        current_measurement = input().strip().split(" ")

        # Add the current measurement to the list
        data.append(current_measurement)
        print(data)

        # Prompt for the next action
        print("Next data point (enter), edit data just taken (e), stop collection (c):")
        
        false_control = True 
        while false_control:
            false_control = False
            control = input().lower().strip("\n")
            print(control)

            if control == "":
                # Move to the next data point
                continue
            elif control == "e":
                # Allow user to re-enter the last measurement
                print("Re-enter the last measurement:")
                current_measurement = input().strip().split(" ")
                data[-1] = current_measurement  # Replace the last measurement
                false_control = True
            elif control == "c":
                # Stop the loop
                stop = True
                print("Data collection stopped.")
            else:
                # Handle invalid commands
                print("Incorrect input. Please try again.")
                false_control = True

    # Write all data to file at the end
    with open(filename, "w") as file:
        for line in data:
            file.write(",".join(map(str, line)) + "\n")

    print(f"All data written to {filename}.")
    return 0

# Run the program
main()
